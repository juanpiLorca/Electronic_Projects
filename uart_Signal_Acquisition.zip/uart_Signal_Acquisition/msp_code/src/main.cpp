#include "Arduino.h"


//int baudRate = 9600;
float offsetDC = 1.65;
float signalDC = 6.5; 
float measuredGain = 0.33;
uint8_t bcd1 = 0b00000001;
uint8_t bcd2 = 0b00000010;
uint8_t bcd3 = 0b00000100;
uint8_t bcd4 = 0b00001000;

// Funcion que entrega un 0 si la señal es menor al 0.25, 1 si es entre 0.25 y 0.75 y 2 si es mayor a 0.75
int compare(float a){
  int value = 0;
  if (a < 0.25 * 3.3){
    value = 0;
  }
  else if (0.25 * 3.3 < a  and  a < 0.75 * 3.3){
    value = 1;
  }
  else{
    value = 2;
  }
  return value;
}

void setup()
{
  // initialize inputs, outputs and reference: 
  pinMode(P6_0, INPUT); // ADC
  pinMode(P3_6, INPUT); // FPGA selector {0,1}

  // Outputs: 
  pinMode(P4_4, OUTPUT); // voltage values (UART: bit bus) ==> Tx (Serial Hardware)
  pinMode(P1_0, OUTPUT); // Led 1
  pinMode(P4_7, OUTPUT); // Led 2

  // initialize serial communication at baud rate (bits per second): 9600 - 115200
  Serial.begin(115200); 
  Serial1.begin(115200);

}
void loop()
{
  // ADC output: signal AC + signal DC
  int digitalValue = analogRead(P6_0); 
  // mapping digital to analog:
  float analogValue = digitalValue * ((3.3 - 0.0)/4095); 
  // shifting the sine wave: 
  // [0.0, 3.30]:
  float analogSignal1 = (analogValue - offsetDC) * (-1) + offsetDC;
  // [3.0, 10.0]:
  float analogSignal2 = (analogValue - offsetDC) * (-1) * 3.03  + signalDC; 

  // FPGA's selector:
  int digitalSelector = digitalRead(P3_6);

  // Serial communication protocol: UART --------------------------
  if (digitalSelector == 0){
    int thouSignal = analogSignal1 * 100;
    uint8_t thouUnit = thouSignal / 1000;
    uint8_t thUnitS = (bcd1 << 4) | thouUnit;
    int centSignal = thouSignal - (thouSignal / 1000) * 1000; 
    uint8_t centUnit = centSignal / 100;
    uint8_t ctUnitS = (bcd2 << 4) | centUnit;
    int decSignal = centSignal - (centSignal / 100) * 100; 
    uint8_t decUnit = decSignal / 10;
    uint8_t dcUnitS = (bcd3 << 4) | decUnit;
    int unitSignal = decSignal - (decSignal / 10) * 10; 
    uint8_t unitUnit = unitSignal / 1;
    uint8_t unUnitS = (bcd4 << 4) | unitUnit; 
    
    Serial1.write(thUnitS);
    Serial1.write(ctUnitS);
    Serial1.write(dcUnitS);
    Serial1.write(unUnitS); 
  }

  else if (digitalSelector == 1){
    int thouSignal = analogSignal2 * 100;
    uint8_t thouUnit = thouSignal / 1000;
    uint8_t thUnitS = (bcd1 << 4) | thouUnit;
    int centSignal = thouSignal - (thouSignal / 1000) * 1000; 
    uint8_t centUnit = centSignal / 100;
    uint8_t ctUnitS = (bcd2 << 4) | centUnit;
    int decSignal = centSignal - (centSignal / 100) * 100; 
    uint8_t decUnit = decSignal / 10;
    uint8_t dcUnitS = (bcd3 << 4) | decUnit;
    int unitSignal = decSignal - (decSignal / 10) * 10; 
    uint8_t unitUnit = unitSignal / 1;
    uint8_t unUnitS = (bcd4 << 4) | unitUnit; 
    
    Serial1.write(thUnitS);
    Serial1.write(ctUnitS);
    Serial1.write(dcUnitS);
    Serial1.write(unUnitS); 
  }
  // ---------------------------------------------------------------

  // Comparador para encendido de LED's
  int comparer = compare(analogSignal1);
      digitalWrite(P1_0, LOW);
      digitalWrite(P4_7, LOW);

  if (comparer == 0){
      digitalWrite(P1_0, LOW);
      digitalWrite(P4_7, LOW);
  }
  else if (comparer == 1){
      digitalWrite(P1_0, LOW);
      digitalWrite(P4_7, HIGH);
  }
  else{
      digitalWrite(P1_0, HIGH);
      digitalWrite(P4_7, LOW);
  }
}